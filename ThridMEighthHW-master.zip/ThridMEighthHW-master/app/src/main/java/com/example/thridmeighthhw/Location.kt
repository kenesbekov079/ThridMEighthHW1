package com.example.thridmeighthhw

data class Location(
    val location: String,
    val name: String
)
